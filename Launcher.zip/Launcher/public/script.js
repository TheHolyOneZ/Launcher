let paths = { games: [], software: [], other: [], domains: [] };
let showPaths = false; 
let showDomains = false; 

fetch('/get-paths')
    .then(res => res.json())
    .then(data => {
        paths = data;
        updateUI();
    });

function togglePaths() {
    showPaths = !showPaths;
    document.querySelectorAll('.path-display').forEach(elem => {
        elem.classList.toggle('hidden-path', !showPaths);
    });
}

function toggleDomains() {
    showDomains = !showDomains;
    document.querySelectorAll('.domain-display').forEach(elem => {
        elem.classList.toggle('hidden-path', !showDomains);
    });
}

function updateUI() {
    for (let category in paths) {
        const list = document.getElementById(`${category}-list`);
        list.innerHTML = '';
        paths[category].forEach((entry, index) => {
            const li = document.createElement('li');
            li.innerHTML = `
                <span class="path-display hidden-path">${entry.path}</span> 
                <span class="domain-display hidden-path">${entry.path}</span> 
                <span>${entry.name || entry.path}</span>
                <button onclick="runPath('${category}', ${index})">Run</button>
                <button onclick="renamePath('${category}', ${index})">Rename</button>
                <button onclick="removePath('${category}', ${index})">Remove</button>
            `;
            list.appendChild(li);
        });
    }
}

// Add path
function addPath(category) {
    const input = document.getElementById(`${category}-path`);
    let path = input.value.trim();

    if (category === 'domains') {
        if (!path.startsWith('http://') && !path.startsWith('https://')) {
            path = 'https://' + path;
        }
    }

    if (path) {
        paths[category].push({ path, name: '' });
        savePaths();
        updateUI(); 
        input.value = ''; 
        switchTab(category); 
    }
}

function renamePath(category, index) {
    const newName = prompt('Enter a new name:', paths[category][index].name || paths[category][index].path);
    if (newName !== null) {
        paths[category][index].name = newName.trim();
        savePaths();
        updateUI();
    }
}

function removePath(category, index) {
    paths[category].splice(index, 1);
    savePaths();
    updateUI();
}

function clearList(category) {
    paths[category] = [];
    savePaths();
    updateUI();
}

function runPath(category, index) {
    const path = paths[category][index].path;
    console.log(`Requesting to run: ${path}`);

    if (category === 'domains') {
        fetch(`/run-domain?path=${encodeURIComponent(path)}`)
            .then(res => res.text())
            .then(alert)
            .catch(err => console.error('Error:', err));
    } else {
        fetch(`/run-app?path=${encodeURIComponent(path)}`)
            .then(res => res.text())
            .then(alert)
            .catch(err => console.error('Error:', err));
    }
}

function savePaths() {
    fetch('/save-paths', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(paths),
    }).catch(err => console.error('Error:', err));
}

function switchTab(tab) {
    document.querySelectorAll('.tab-content').forEach(content => {
        content.style.display = 'none';
    });

    document.getElementById(tab).style.display = 'block';
}
