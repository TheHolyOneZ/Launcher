import express from 'express';
import fs from 'fs';
import { exec } from 'child_process';
import open from 'open'; // Correct way to import the 'open' module using ES module syntax
import path from 'path';

const app = express();
const port = 3250;

// Path to the JSON file that stores the paths
const pathsFile = './paths.json';

// Serve static files (HTML, CSS, JS)
app.use(express.static('public'));
app.use(express.json());

// Endpoint to get saved paths
app.get('/get-paths', (req, res) => {
    console.log('Request received at /get-paths');
    if (fs.existsSync(pathsFile)) {
        fs.readFile(pathsFile, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading paths file:', err);
                return res.status(500).send('Server Error');
            }
            console.log('Paths retrieved successfully');
            res.json(JSON.parse(data));
        });
    } else {
        console.log('Paths file does not exist. Returning empty paths.');
        res.json({ games: [], software: [], other: [], domains: [] });
    }
});

// Endpoint to save paths
app.post('/save-paths', (req, res) => {
    console.log('Request received at /save-paths');
    console.log('Request body:', req.body);
    fs.writeFile(pathsFile, JSON.stringify(req.body, null, 2), (err) => {
        if (err) {
            console.error('Error saving paths:', err);
            return res.status(500).send('Server Error');
        }
        console.log('Paths saved successfully');
        res.send('Paths saved successfully');
    });
});

// Endpoint to run a file (supports various file types)
app.get('/run-app', (req, res) => {
    const filePath = req.query.path;
    if (!filePath) {
        console.log('No file path provided in the request');
        return res.status(400).send('File path is required');
    }

    const fileExt = path.extname(filePath).toLowerCase();
    console.log(`Request to run file: ${filePath}, Extension: ${fileExt}`);

    // Executables
    if (['.exe', '.bat', '.cmd', '.msi', '.apk', '.app', '.run', '.dmg', '.pkg', '.deb', '.rpm', '.bin', '.exe.config'].includes(fileExt)) {
        exec(`start "" "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error running executable: ${err}`);
                return res.status(500).send(`Failed to run executable: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Running executable: ${filePath}`);
        });
    }
    // Shell Script
    else if (fileExt === '.sh') {
        exec(`bash "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error running shell script: ${err}`);
                return res.status(500).send(`Failed to run shell script: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Running shell script: ${filePath}`);
        });
    }
    // Python Script
    else if (fileExt === '.py') {
        exec(`python "${filePath}" || python3 "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error running Python script: ${err}`);
                return res.status(500).send(`Failed to run Python script: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Running Python script: ${filePath}`);
        });
    }
    // Java
    else if (fileExt === '.jar') {
        exec(`java -jar "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error running Java file: ${err}`);
                return res.status(500).send(`Failed to run Java file: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Running Java file: ${filePath}`);
        });
    }
    // Ruby Script
    else if (fileExt === '.rb') {
        exec(`ruby "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error running Ruby script: ${err}`);
                return res.status(500).send(`Failed to run Ruby script: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Running Ruby script: ${filePath}`);
        });
    }
    // Perl Script
    else if (fileExt === '.pl') {
        exec(`perl "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error running Perl script: ${err}`);
                return res.status(500).send(`Failed to run Perl script: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Running Perl script: ${filePath}`);
        });
    }
    // Web Scripts (PHP, ASP, JSP)
    else if (['.php', '.asp', '.jsp'].includes(fileExt)) {
        exec(`start "" "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error running web script: ${err}`);
                return res.status(500).send(`Failed to run web script: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Running web script: ${filePath}`);
        });
    }
    // Media Files
    else if (['.mp3', '.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.ogg', '.mpg', '.3gp', '.wav', '.aac', '.m4v', '.aiff', '.flac', '.wma'].includes(fileExt)) {
        exec(`start "" "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error opening media file: ${err}`);
                return res.status(500).send(`Failed to open media file: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Opening media file: ${filePath}`);
        });
    }
    // Documents
    else if (['.pdf', '.docx', '.xlsx', '.pptx', '.txt', '.rtf', '.html', '.xml', '.json', '.csv', '.md', '.epub', '.chm', '.xps'].includes(fileExt)) {
        exec(`start "" "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error opening document: ${err}`);
                return res.status(500).send(`Failed to open document: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Opening document: ${filePath}`);
        });
    }
    // Compressed Files
    else if (['.tar', '.tar.gz', '.gz', '.iso', '.zip', '.rar', '.7z', '.torrent'].includes(fileExt)) {
        exec(`start "" "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error opening compressed file: ${err}`);
                return res.status(500).send(`Failed to open compressed file: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Opening compressed file: ${filePath}`);
        });
    }
    // Configuration Files
    else if (['.json', '.xml', '.yml', '.config', '.plist', '.reg', '.exe.config', '.jar.config'].includes(fileExt)) {
        exec(`start "" "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error opening config file: ${err}`);
                return res.status(500).send(`Failed to open config file: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Opening config file: ${filePath}`);
        });
    }
    // URL/Shortcut Files
    else if (['.url', '.desktop'].includes(fileExt)) {
        exec(`start "" "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error opening URL shortcut: ${err}`);
                return res.status(500).send(`Failed to open URL shortcut: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Opening URL shortcut: ${filePath}`);
        });
    }
    // Other Files (e.g., .swf, .wsf, .vbe, .xaml, .xpi, etc.)
    else if (['.swf', '.wsf', '.vbe', '.xaml', '.xpi'].includes(fileExt)) {
        exec(`start "" "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                console.error(`Error opening file: ${err}`);
                return res.status(500).send(`Failed to open file: ${err.message}`);
            }
            console.log(stdout);
            res.send(`Opening file: ${filePath}`);
        });
    }
    else {
        console.error('Unsupported file type:', fileExt);
        res.status(400).send('Unsupported file type');
    }
});

// Endpoint to open a domain in the browser
app.get('/run-domain', (req, res) => {
    const domain = req.query.path; // Use 'path' to align with previous code and consistency with your frontend
    console.log(`Request received at /run-domain with domain: ${domain}`);
    
    if (!domain) {
        console.error('Domain not provided in the request');
        return res.status(400).send('Domain is required');
    }

    console.log(`Opening domain: ${domain}`);

    // Open the domain URL in the default browser
    open(domain).then(() => {
        console.log(`Successfully opened domain: ${domain}`);
        res.send(`Opening domain: ${domain}`);
    }).catch((err) => {
        console.error(`Error opening domain: ${err}`);
        res.status(500).send(`Failed to open domain: ${err.message}`);
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running at http://127.0.0.1:${port}`);
});
